gcc q1.c -o q1
gcc q2.c -o q2
gcc q3.c -o q3