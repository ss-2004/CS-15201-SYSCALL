clang drvr.c -o d.out
clang repo.c -o r.out
clang hare.c -o h.out
clang tort.c -o t.out
clang god.c -o g.out